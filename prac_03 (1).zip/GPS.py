def main():
    import random
    population=1000
    print("Welcome to the Gopher Population Simulator!")
    print("Starting population: {}\n".format(population))

    for i in range(10):
        print("Year {}".format(i+1))
        print("*****")
        birth_num=int(random.uniform(0.1,0.2)*population)
        death_num=int(random.uniform(0.05,0.25)*population)
        population=population+birth_num-death_num
        print("{} gohers were born. {} died.".format(birth_num,death_num))
        print("Population: {}\n".format(population))


main()
