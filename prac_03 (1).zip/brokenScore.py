"""
CP1404/CP5632 - Practical
Broken program to determine score status
"""

def main():
    print (check_score())



def check_score():
    score = float(input("Enter score: "))
    if score < 0:
        record ="Invalid score"
    else:
        if score > 100:
            record ="Invalid score"
        elif score >= 90:
            record ="Excellent"
        elif score >= 50:
            record ="Passable"
        else:
            record ="Bad"
    return record

main()


