def main():
    userName = get_name()
    print_name(userName)


def print_name(userName):
    num=int(input("Enter the frequency of letters"))
    line_num=len(userName)//num+1
    for i in range (line_num):
        line_letter=''
        for chr in range(num):
            if (i*num+chr)>=len(userName):
                break
            line_letter=line_letter+userName[i*num+chr]
        print (line_letter)


def get_name():
    userName = input("Enter your name")
    while not userName.isalpha():
            userName = input("Invalid. Enter a name which only includes letters.")
    return userName


main()