def main():
    char=ord(input("Enter a character: "))
    print("The ASCII code for {} is {}".format(chr(char),char))
    number=check_range(check_digit(input("Enter a number between 33 and 127: ")))

    print("The character for {} is {}".format(number,chr(number)))


def check_digit(number):
    while not number.isdigit():
        print("Please enter a valid number!")
        print("Enter a number ({} -{}): ".format(lower, upper))
        number=input()
    return int(number)

lower=10
upper=50

def get_number(lower,upper):
    number=check_digit(input("Enter a number ({}-{}): ".format(lower,upper)))
    while number<lower or number>upper:
        print("Please enter a valid number!")
        print("Enter a number ({}-{}): ".format(lower,upper))
        number=check_digit(input())
    return int(number)

column=get_number(lower,upper)
for i in range(33,127,column):
    line_char=''
    if i+column>127:
        for j in range(i, 128):
            line_char = line_char + "{:>10d}{:>3}".format(j, chr(j))
    else:
        for j in range(i,i+column):
            line_char=line_char+"{:>10d}{:>3}".format(j,chr(j))
    print(line_char)
main()