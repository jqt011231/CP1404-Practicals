""""
Name: Jia Qi Tan
Date started: 20-8-2019
Github URL:

"""

import csv

global_list = []

def main():
    print("Travel Tracker 1.0 by Jia Qi Tan")
    open_csv()
    menu_list()

def menu_list():
    print("Menu")
    print("\tL - List places")
    print("\tA - Add new place")
    print("\tM - Mark a place as visited")
    print("\tQ - Quit")
    menu = str(input('>>> ')).upper()
    while menu != "Q" and menu != "q":  # loop that will keep display the menu to the user until the user chooses to quit
        if menu == "L" or menu == "l":
            show_list()
        elif menu == "A" or menu == "a":
            add_to_list()
        elif menu == "M":
            mark_place()
        else:
            print("Invalid input")
        print("Menu")
        print("\tL - List places")
        print("\tA - Add new place")
        print("\tM - Mark a place as visited")
        print("\tQ - Quit")
        menu = str(input('>>> ')).upper()
    write_csv()
    quit_message()

def write_csv():
    with open('places.csv', 'w', newline='') as write_file:
        writer = csv.writer(write_file)
        writer.writerows(global_list)
    write_file.close()

def open_csv():
    with open('places.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=",")
        sort_csv = sorted(csv_reader, key = lambda row:(row[3],int(row[2])))
        for places in sort_csv:
            global_list.append(places)
    csv_file.close()


def show_list():
    list_arrange = sorted(global_list, key=lambda row: (row[3], int(row[2])))
    for num, line in enumerate(list_arrange):
        if line[3] == "n":
            print("*{:<0} {:<10}{:<7s}{:<15}{:>0}{:>5}".format(num + 1, line[0], "in", line[1], "priority", line[2]))
        else:
            print(" {:<0} {:<10}{:<7s}{:<15}{:>0}{:>5}".format(num + 1, line[0], "in", line[1], "priority", line[2]))
    visit_place = non_visit_place_detail()
    if visit_place == True:
        print("{} places. Do you still want to visit these places again?", format(len(global_list), non_visit_place_detail()))
    else:
        print("{} places. Opps, you have no places to visit left. Wish to add more?", format(len(global_list)))

def add_to_list():
    name = str(input("Please enter name:"))
    while name == "" or name.isdigit():
        print("Invalid name")
        name = str(input("Please enter name:"))
    country = str(input("Please enter country:"))
    while country == "" or country.isdigit():
        print("Invalid country")
        country = str(input("Please enter country:"))
    while True:
        try:
            priority = int(input("Please enter priority:"))
            if priority == "" :
                print ("Invalid priority")
                priority = int(input("Please enter priority:"))
            elif priority <=0:
                print("Num must be >0")
                priority = int(input("Please enter priority:"))
            else:
                break
        except ValueError:
            print("Invalid value")
    adding_to_list(name, country, priority)
    print("{} in {} (priority {}) added to Travel Tracker".format(name,country,priority))

def mark_place():
    list_arrange = sorted(global_list,key=lambda row: (row[3], int(row[2])))
    visit_place = non_visit_place_detail()
    if visit_place == True:
        show_list()
        line_in_list = check_errors()
        if  list_arrange[line_in_list-1][3] == "v":
            print("You have visited this place already. Choose another?")
        else:
            list_arrange[line_in_list-1][3] = "v"
            print("{} in {} visited".format((list_arrange[line_in_list-1][0], list_arrange[line_in_list-1][1])))
    else:
        print("You have no unvisited place.")

def non_visit_place():
    non_visit_place = 0
    for line in global_list:
        if line [3] == "v":
            non_visit_place+=0
        elif line[3] =="n":
            non_visit_place+=1
    return non_visit_place

def adding_to_list(name, country, priority):
    place_to_add = []
    place_to_add.append(name)
    place_to_add.append(country)
    place_to_add.append(priority)
    place_to_add.append("n")
    global_list.append(place_to_add)

def check_errors():
    places_num = 0
    visit_place = 0
    for line in global_list:
        places_num+=1
        if line[3] == "v":
            visit_place+=0
        elif line[3] == "n":
            visit_place+=1
    while True:
        try:
            line_in_list =  int(input("Please enter a number of a place mark as visited"))
            if line_in_list <=0:
                print("number must be >0")
            elif line_in_list == "":
                print("Invalid value")
            elif line_in_list > places_num:
                print("Please enter number according to the list")
            else:
                break
        except ValueError:
            print("Invalid value")
    return line_in_list

def quit_message():
    places_num = 0
    visit_place = 0
    for line in global_list:
        places_num+=1
        if line[3] =="v":
            visit_place+=0
        elif line[3] == "n":
            visit_place+=1
    print(places_num,"Places have been added successfully!")

def non_visit_place_detail():
    places_num = 0
    visit_place = 0
    for line in global_list:
        places_num+=1
        if line [3] =="v":
            visit_place+=1
        elif line[3] == "n":
            visit_place+=0
    if places_num - visit_place == 0:
        return False
    else:
        return True

main()





