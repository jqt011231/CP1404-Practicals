"""(Incomplete) Tests for PlaceCollection class."""
from placecollection import PlaceCollection
from place import Place

import csv


def run_tests():
    print("Test empty PlaceCollection:")  # Test empty PlaceCollection (defaults)
    collection_places=PlaceCollection()
    print(collection_places)
    assert not collection_places.places  # an empty list is considered False

    print("Test loading places:")  # Test loading places
    collection_places.load_places('places.csv')
    print(collection_places)
    assert collection_places.places  # assuming CSV file is non-empty considered True

    print("Test new added place:")  # Test adding a new Place with values
    collection_places.add_place(Place("Smithfield", "Australia", 5, False))
    print(collection_places.places)

    print("Test sorting places by priotity:")  # Test sorting places
    from operator import itemgetter
    collection_places.places.sort(
        key=itemgetter(2))
    print(collection_places)

    print("Test sorting places by alphabetical:")  # Test alphabetical sorting
    collection_places.sort_alphabetically(collection_places.places)
    print(collection_places)

    print("Test sorting places by visited status")
    collection_places.sort_visited(collection_places.places)
    print(collection_places)

    print("Test saving:")  # save file from places list in csv file
    collection_places.save_file('places.csv')


run_tests()
