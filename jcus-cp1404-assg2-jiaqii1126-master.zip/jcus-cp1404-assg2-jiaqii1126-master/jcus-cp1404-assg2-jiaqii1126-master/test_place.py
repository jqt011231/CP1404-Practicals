"""
Basic Kivy test code
If this works, it will produce a GUI window with "hello world" in the middle
and you know you have set everything up correctly.
It also prints the Python version in the run output (may be mixed in with Kivy output)
"""

from place import Place


def run_test():
    """Test Place class."""

    print(">>>Test empty place:")   # test default empty place
    current_place = Place()
    print(current_place)
    assert current_place.name == ""
    assert current_place.country == ""
    assert current_place.priority == 0
    assert not current_place.is_visited

    print(">>>Test initial-value place:")   # test initial value place
    new_place = Place("Malagar", "Spain", 1, False)
    print(new_place)

    print(">>>Test alternate method for marking visited:")   # is_visited value change from bocluen to string
    new_place = Place("Malagar", "Spain", 1, "n")
    print(new_place)

    # TODO: Write tests to show this initialisation works
    print(new_place)  # string representation of place
    print(new_place.check_visited())  # check if place is visited or unvisited
    print("hello {}".format(new_place.is_important()))  # important place is added to this list

    # TODO: Add more tests, as appropriate, for each method


run_test()
