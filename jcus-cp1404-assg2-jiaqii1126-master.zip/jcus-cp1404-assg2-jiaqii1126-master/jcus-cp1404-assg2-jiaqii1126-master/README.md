# CP1404 Assignment 2: Travel Tracker 2.0 by TAN JIA QI

_Edit this README, replacing this line and above with your own name/details._  
_At the end of the project, complete the project reflection below by answering the questions (replace the ... parts)._
_Note that to get high marks for this, your reflection should match the "exemplary" description from the rubric:_

> The project reflection is complete and describes development and learning well, shows careful thought, highlights insights made during code development.


## 1. How long did the entire project (assignment 2) take you?
...  

## 2. What are you most satisfied with?
...

## 3. What are you least satisfied with?
...

## 4. What worked well in your development process?
...

## 5. What about your process could be improved the next time you do a project like this?
...

## 6. Describe what learning resources you used and how you used them.
...

## 7. Describe the main challenges or obstacles you faced and how you overcame them.
... 

## 8. Briefly describe your experience using classes and if/how they improved your code.
...