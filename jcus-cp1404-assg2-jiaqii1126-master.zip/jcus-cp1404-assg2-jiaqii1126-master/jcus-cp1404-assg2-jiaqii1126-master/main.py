"""
Name:Tan Jia Qi
Date:20/9/2019
Brief Project Description: CP1404 Assignment 2 Travel Tracker 2.0 by TAN JIA QI
GitHub URL: https://github.com/JCUS-CP1404/jcus-cp1404-assg2-jiaqii1126
"""
# Create your main program in this file, using the TravelTrackerApp class

from kivy.app import App
from kivy.lang import Builder
from kivy.uix.button import Button
from placecollection import PlaceCollection
from place import Place


class TravelTrackerApp(App):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        travel_locations = PlaceCollection()
        self.app_list = travel_locations.load_places('places.csv')

    def build(self):
        self.title = "Travel Tracker App by Tan Jia Qi"
        self.root = Builder.load_file('app.kv')
        self.create_widgets()
        return self.root

    def clear_input(self):
        self.root.ids.input_name.text = ""
        self.root.ids.input_country.text = ""
        self.root.ids.input_priority.text = ""

    def create_widgets(self):
        for location in self.app_list:
            # Create a button for each PlaceCollection object, specifying the text
            temp_button = Button(
                text="{} in {}, priority {} ({})".format(location[0], location[1], location[2], location[3]))
            temp_button.bind(on_release=self.press_entry)
            # Store a reference to the location object in the button object
            temp_button.location = location
            self.root.ids.entries_box.add_widget(temp_button)

    def press_entry(self, instance):
        """this function will change the place's visited/unvisited status upon pressing"""
        # Each button was given its own ".location" object reference, so we can get it directly
        location = instance.location
        if location[3] == "Visited":
            location[3] = "Unvisited"
        else:
            location[3] = "Visited"
        # Update button text and label
        instance.text = "{} in {}, priority {} ({})".format(location[0], location[1], location[2], location[3])

    def add_place(self):
        if str(self.name_input.text).strip() == '' or str(self.country_input.text).strip() == '' or str(
                self.priority_input.text).strip() == '':
            self.root.ids.bottom_layout.text = "Please dont leave blank."
        else:
            try:
                if int(self.priority_input.text) < 0:
                    print(type(placecollection.places))
                    self.root.ids.bottom_layout.text = "Please enter a valid digit number!"
                else:
                    self.places_list.add_place(self.name_input.text, self.country_input.text,
                                               int(self.priority_input.text))
                    self.places_list.sort(self.spinner.text)
                    self.clear_fields()
                    self.root.ids.right_layout.clear_widgets()
                    self.build_widgets_right_col()
            except ValueError:
                self.root.ids.bottom_layout.text = "Please enter a number inside priority field."


TravelTrackerApp().run()
