# Copy your first assignment to this file, then update it to use Place class
# Optionally, you may also use PlaceCollection class

""""
Name: Jia Qi Tan
Date started: 20-8-2019
Github URL:

"""

import csv
import sys
from place import Place
from placecollection import PlaceCollection

global_list=PlaceCollection()

"""mostly just renamed a lot of variables to fit witb the classes"""
"""tweaked some variables in the lists so the format is more uniform"""


def user_name():
    print("Welcome user!")
    user_name=input("What is your name?: ")
    while user_name == "":
        print("Your name cannot be blank!")
        user_name=input("What is your name?: ")
    print("Hello {}!".format(user_name))


# show the menu
def show_menu():
    print("Menu:")
    print("L - List places")
    print("A - Add new place")
    print("M - Mark a place as visited")
    print("Q - Quit")


def list_out_places():
    number_list=0
    unvisited_places=0

    for row in global_list:
        if row[3] == "Visited":
            number_list+=1
            print("{:>2}. {:<{}} in {:>{}} priority {}".format(number_list, row[0], 20, row[1], 20, row[2]))
        else:
            number_list+=1
            print("*{}. {:<{}} in {:>{}} priority {}".format(list_numb, row[0], 20, row[1], 20, row[2]))
            unvisited_places+=1
    return unvisited_places  # TODO COME BACK AND REVIEW THIS


def execute_menu():
    show_menu()

    menu_choice=input("Please choose one of the above options: ").upper()
    if menu_choice == "L":
        unvisited_places=list_out_places()

        if unvisited_places > 0:
            print("{} places. You still want to visit {} places.".format(unvisited_places, unvisited_places))
        else:
            print("No unvisited places.")

    elif menu_choice == "A":
        give_name=input("What is the place's name?: ")
        while give_name == "":
            print("Please enter a location!")
            give_name=input("What is the place's name?: ")
        extra_list=[]
        extra_list.append(give_name)

        give_country=input("What country is this in?: ")
        while give_country == "":
            print("Please enter a location!")
            give_country=input("What country is this in?: ")
        extra_list.append(give_country)

        give_priority=input("What priority would you assign to visiting this location?: ")
        while give_priority != "":
            try:
                val=int(give_priority)
                print("Input number value is: ", val)
                break
            except ValueError:
                print("That's not an number!")
                print("Please key in a number.")
                give_priority=input("What priority would you assign to visiting this location?: ")
        extra_list.append(give_priority)
        extra_list.append("Unvisited")
        globsl_list.append(extra_list)

    elif menu_choice == "M":
        unvisited_places=list_out_places()
        rows=0
        if unvisited_places == 0:
            print("There are no more unvisited places.")
        else:
            edit_mark=input("Which place would you like to mark as visited?: ")
            for item in global_list:
                rows+=1
                if edit_mark in item:
                    index_numb=global_list.index(item)
                    global_list[index_numb][3]="Visited"
                    print("FOUND IT! The list has been updated!")
                    break
                else:
                    print("This is not in row {}.".format(rows))
    elif menu_choice == "Q":
        global_list.save_file('places.csv')
        print("Thank you and goodbye!")
        sys.exit()
    else:
        print("That was an invalid input.")
        execute_menu()

    execute_menu()


def main():
    # load file
    # get name
    # execute menu
    """load the csv file"""
    global_list.places('places.csv')
    user_name()  # get the user's name
    execute_menu()  # most of the functions from assignment 1 are in this function


main()
