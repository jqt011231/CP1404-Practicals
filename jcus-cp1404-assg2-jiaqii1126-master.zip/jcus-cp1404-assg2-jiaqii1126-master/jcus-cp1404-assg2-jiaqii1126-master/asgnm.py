import csv
import sys


def open_file():  # loading places list
    global global_list
    with open('places.csv', 'r') as file:
        reader = csv.reader(file)
        global_list = list(reader)


def save_file():  # save file inside option "Q" of executed menu updates to csv file
    with open('places.csv', 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerows(global_list)


def get_name():  # getting username and printing
    print("Halo and nice to meet you! Welcome to Travel Tracker by Tan Jia Qi!")
    user_name=input("Please enter your name: ")
    while user_name == "":
        print("Please don't leave blank. Give yourself a name!")
        user_name = input("Please enter your name: ")
    print("Hello and Welcome to Travel Tracker by Tan Jia Qi{}!".format(user_name))


def show_menu():  # showing the menu list for the users
    print("Menu:")
    print("L - List places")
    print("A - Add new place")
    print("M - Mark a place as visited")
    print("Q - Quit")


def list_out_places():  # accesses the csv file and formats the display when print 'L' result
    number_list = 0
    unvisited_places = 0
    max_length = 0
    for row in global_list:
        for item in row:
            if len(item) > max_length:
                max_length = len(item)
    for row in global_list:
        if row[3] == "v":
            number_list += 1
            print(
                "{:>2}. {:<{}} in {:>{}} priority {}".format(number_list, row[0], max_length, row[1], max_length, row[2]))
        else:
            number_list += 1
            print("*{}. {:<{}} in {:>{}} priority {}".format(number_list, row[0], max_length, row[1], max_length, row[2]))
            unvisited_places += 1
    return unvisited_places


def execute_menu():   # executes users choice
    show_menu()
    menu_choice = input("Please choose and continue: ").upper()
    if menu_choice == "L":
        unvisited_places = list_out_places()
        if unvisited_places > 0:
            print("{} places. You still left {} place that unvisited.".format(unvisited_places, unvisited_places))
        else:
            print("You have left no unvisited places. Any plan to travel new places?")

    elif menu_choice == "A":
        give_name = input("Enter the name of the place you want: ")
        while give_name == "":
            print("Please do not leave blank. I am glad you enter something!")
            give_name = input("Enter the name of the place you want: ")
        extra_list = []
        extra_list.append(give_name)

        give_country = input("Enter the country: ")
        while give_country == "":
            print("Please do not leave blank. I am glad you enter something!")
            give_country = input("Enter the country: ")
        extra_list.append(give_country)

        give_priority = input("Enter the priority for this location: ")
        while give_priority != "":
            try:
                val = int(give_priority)
                print("You have given", val, "priority fot this location.")
                break
            except ValueError:
                print("Please given digit number only!")
                print("Enter the priority for this location:")
                give_priority = input("What priority would you assign to visiting this location?: ")
        extra_list.append(give_priority)
        extra_list.append("n")
        global_list.append(extra_list)

    elif menu_choice == "M":
        unvisited_places = list_out_places()
        rows = 0
        if unvisited_places == 0:
            print("You have no place left unvisited. Wish to add new place?")
        else:
            edit_mark = input("Which place would you want to mark as visited?: ")
            for item in global_list:
                rows += 1
                if edit_mark in item:
                    index_numb = global_list.index(item)
                    global_list[index_numb][3] = "v"
                    print("The place you want to mark is in the list!")
                    break
                else:
                    print("Sorry, the place you enter is not in the current list.".format(rows))
    elif menu_choice == "Q":
        save_file()
        print("Thank you and goodbye! Have a nice day.")
        sys.exit()
    else:
        print("You have entered an invalid input. Please try again.")
        execute_menu()

    execute_menu()


def main():
    open_file()
    get_name()
    execute_menu()


main()
