userName=str(input("What is your name?"))
OUTPUT_FILES =("your_name.txt")
outfile = open(OUTPUT_FILES, 'w')
print("Your name is {}".format(userName), file=outfile)
outfile.close()

input_file = open("numbers.txt", 'r')
num1, num2 = input_file.readlines()
sum = int(num1) + int(num2)
print (sum)



